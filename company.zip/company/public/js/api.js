async function getAndDisplay(path) {
    const response = await fetch(path);
    const json = await response.json();
    
    const dataDiv = document.querySelector('.data');

    dataDiv.innerHTML = JSON.stringify(json);
}